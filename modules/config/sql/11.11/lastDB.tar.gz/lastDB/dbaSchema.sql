DROP 	SCHEMA dba CASCADE;

SET 	statement_timeout 	= 0;
SET 	client_encoding 	= 'UTF8';
SET 	standard_conforming_strings = off;
SET 	check_function_bodies 	= false;
SET 	client_min_messages	= warning;
SET 	escape_string_warning 	= off;

CREATE 	SCHEMA dba;
ALTER 	SCHEMA dba OWNER TO postgres;
SET 	search_path = dba, pg_catalog;

CREATE FUNCTION  dba.getctrl_parameters(in_identificador text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE  
	identif text;
BEGIN
	SELECT  lower(TRIM(valor))  into identif
	FROM	dba.ctrl_parameters
 	WHERE 	identificador = in_identificador;
	RETURN  identif;
END;
$$;

CREATE FUNCTION  dba.ifternario(boolean, text, text) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, numeric, numeric) RETURNS numeric
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, timestamp without time zone, timestamp without time zone) RETURNS timestamp without time zone
LANGUAGE plpgsql
AS $_$
DECLARE
BEGIN
    RETURN ( CASE WHEN ($1 IS true) THEN $2 ELSE $3 END );
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, integer, integer) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, character varying, character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, bigint, bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, bit, bit) RETURNS bit
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, bit varying, bit varying) RETURNS bit varying
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, boolean, boolean) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, box, box) RETURNS box
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, bytea, bytea) RETURNS bytea
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, character, character) RETURNS character
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, cidr, cidr) RETURNS cidr
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, circle, circle) RETURNS circle
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, date, date) RETURNS date
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, double precision, double precision) RETURNS double precision
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, inet, inet) RETURNS inet
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, interval, interval) RETURNS interval
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, line, line) RETURNS line
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, lseg, lseg) RETURNS lseg
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, macaddr, macaddr) RETURNS macaddr
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, money, money) RETURNS money
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, path, path) RETURNS path
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, point, point) RETURNS point
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, polygon, polygon) RETURNS polygon
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, real, real) RETURNS real
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, smallint, smallint) RETURNS smallint
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, time without time zone, time without time zone) RETURNS time without time zone
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, time with time zone, time with time zone) RETURNS time with time zone
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, timestamp with time zone, timestamp with time zone) RETURNS timestamp with time zone
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, tsquery, tsquery) RETURNS tsquery
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, tsvector, tsvector) RETURNS tsvector
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, txid_snapshot, txid_snapshot) RETURNS txid_snapshot
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, uuid, uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.ifternario(boolean, xml, xml) RETURNS xml
    LANGUAGE plpgsql
    AS $_$
DECLARE
BEGIN
    RETURN (CASE WHEN ($1 IS true) THEN $2 ELSE $3 END);
END;
$_$;

CREATE FUNCTION  dba.new_pkfields(text) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
       str   	text;
       i 	integer;
       linha 	record;
begin
     str := '';
     i := 0;
     FOR linha 	IN (SELECT coluna 
		FROM dba.new_primarykey 
		WHERE trim(tabela)=trim($1)
	)LOOP
	if (i = 0) THEN	str := linha.coluna;
        else 		str := str||','||linha.coluna;
        end if;
        i := i + 1;
     END LOOP;

     if (length(str) > 0) then	str := 'CONSTRAINT pk_'||$1||' PRIMARY KEY ('|| str ||')';
     else     			str := NULL;
     end if;
     return str ;
end; 
$_$;



CREATE OR REPLACE FUNCTION dba.new_pkfields2(text)
  RETURNS text AS
$BODY$
DECLARE
       str   	text;
       i 	integer;
       linha 	record;
begin
     str := '';
     i := 0;
     FOR linha 	IN (SELECT coluna 
		FROM dba.new_primarykey 
		WHERE trim(tabela)=trim($1)
	)LOOP
	if (i = 0) THEN	str := linha.coluna;
        else 		str := str||','||linha.coluna;
        end if;
        i := i + 1;
     END LOOP;

     if (length(str) > 0) then	str := str ;
     else     			str := NULL;
     end if;
     return str ;
end; 
$BODY$  LANGUAGE plpgsql;


ALTER FUNCTION dba.new_pkfields(text) OWNER TO postgres;

CREATE FUNCTION  dba.nvl(bigint, bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(bit, bit) RETURNS bit
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(bit varying, bit varying) RETURNS bit varying
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(boolean, boolean) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(box, box) RETURNS box
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(bytea, bytea) RETURNS bytea
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(character varying, character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(character, character) RETURNS character
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(cidr, cidr) RETURNS cidr
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(circle, circle) RETURNS circle
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(date, date) RETURNS date
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(double precision, double precision) RETURNS double precision
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(inet, inet) RETURNS inet
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(integer, integer) RETURNS integer
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(interval, interval) RETURNS interval
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(line, line) RETURNS line
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(lseg, lseg) RETURNS lseg
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(macaddr, macaddr) RETURNS macaddr
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(money, money) RETURNS money
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(numeric, numeric) RETURNS numeric
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(path, path) RETURNS path
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(point, point) RETURNS point
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(polygon, polygon) RETURNS polygon
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(real, real) RETURNS real
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(smallint, smallint) RETURNS smallint
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(text, text) RETURNS text
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(time without time zone, time without time zone) RETURNS time without time zone
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.nvl(timestamp without time zone, timestamp without time zone) RETURNS timestamp without time zone
    LANGUAGE plpgsql
    AS $_$DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END$_$;

CREATE FUNCTION  dba.old_pkfields(text) RETURNS text
    LANGUAGE plpgsql
    AS $_$
DECLARE
       str   	text;
       i 	integer;
       linha 	record;
begin
     str := '';
     i := 0;
     for linha in SELECT coluna 
 FROM dba.old_primarykey 
 WHERE trim(tabela)=trim($1) loop
	if (i = 0) then
           str := linha.coluna;
        else
	   str := str||','||linha.coluna;
        end if;
        i := i + 1;
     end loop;
     if (length(str) > 0) then
          str := 'CONSTRAINT pk_'||$1||' PRIMARY KEY ('|| str ||')';
     else     
	  str := NULL;
     end if;
     return str ;
end; 
$_$;

CREATE FUNCTION  dba.save_log(text) RETURNS void
    LANGUAGE plpgsql
    AS $_$ DECLARE
BEGIN
    INSERT INTO ctrl_log(idlog, datahora, descricao) VALUES (CAST((SELECT COUNT(idlog)+1 FROM ctrl_log ) AS INTEGER) ,now(),$1);
END; 
$_$;

CREATE FUNCTION  dba.script_create_new_contraints() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    linha  RECORD;
    in_schema text;
BEGIN
	linha 	  := NULL;
	in_schema := dba.getctrl_parameters('oldSchema');
	FOR linha IN (	
		SELECT (' ALTER TABLE '||in_schema||'.'||n.table_name||' ADD '||n.script_pk||';') script			
		FROM 	dba.new_tables n	
		WHERE 	n.script_pk is not null
		AND	trim(lower(n.table_name)) in ( SELECT trim(lower(o.table_name)) FROM dba.old_tables o)
	)LOOP
		EXECUTE linha.script;
	END LOOP;

	linha := NULL;
	
	FOR linha IN (	SELECT (' ALTER TABLE '||in_schema||'.'||n.tabela||' ADD CONSTRAINT '||n.chave||' '||replace(criar_sql,'"'||dba.getctrl_parameters('newSchema')||'"','"'||dba.getctrl_parameters('oldSchema')||'"')) script
			FROM 	dba.new_foreignkeys n
			WHERE	trim(lower(n.tabela)) in ( SELECT trim(lower(o.table_name)) FROM dba.old_tables o)
	)LOOP
		EXECUTE linha.script;
	END LOOP;

	RETURN 1;
END;
$$;

CREATE FUNCTION  dba.script_diff_fields() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    fields  RECORD;
BEGIN
	FOR fields IN (	
		SELECT 	script 
		FROM 	dba.new_fields
 		WHERE  (lower(trim(table_name))||'.'||lower(trim(column_name))) NOT IN( SELECT (lower(trim(table_name))||'.'||lower(trim(column_name))) as "fields0" FROM 	dba.old_fields)
	)LOOP
		EXECUTE fields.script;
	END LOOP;
	RETURN 1;
END;
$$;

CREATE FUNCTION  dba.script_diff_fields_sizes() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    fields  RECORD;
BEGIN
	FOR fields IN (	
		SELECT('ALTER TABLE '||dba.getctrl_parameters('oldSchema')||'.'||n.table_name||' ALTER '||n.column_name||' TYPE '||n.data_type||'('||n.precisao||');') as script
		FROM  	dba.new_fields n,
			dba.old_fields o
		WHERE   n.table_name 	=   o.table_name
		AND   	n.column_name 	=   o.column_name
		AND   	n.precisao 	<>  o.precisao
	)LOOP
		EXECUTE fields.script;
	END LOOP;
	RETURN 1;
END;
$$;

CREATE FUNCTION  dba.script_diff_fields_types() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    fields  RECORD;
BEGIN

FOR fields IN (	
		SELECT	table_name, column_name, data_type, precisao  
		FROM 	dba.old_fields
		WHERE   trim(data_type) = 'numeric' 
		AND	trim(precisao)  = '32,0'
	)LOOP
		EXECUTE 'ALTER TABLE '||dba.getctrl_parameters('oldSchema')||'.'||fields.table_name||' ALTER '||fields.column_name||' TYPE integer;';
	END LOOP;

	FOR fields IN (	
		SELECT 	s.table_name, s.column_name, s.data_type, s.create_temp_field, s.drop_old_field, s.create_new_field_type, s.swap_data_to_new_field, s.drop__temp_field	
		
 FROM  	dba.new_fields_swap_type s,
			dba.new_fields n,
			dba.old_fields o
		
 WHERE  (trim(s.table_name)||'.'||trim(s.column_name)) = (trim(n.table_name)||'.'||trim(n.column_name))	
		
	AND 	n.table_name 	=   o.table_name
		
	AND   	n.column_name 	=   o.column_name
		
	AND   	n.data_type 	<>  o.data_type
	)LOOP
		EXECUTE DBA.NVL(fields.create_temp_field::text,'SELECT 1;'::text)::text;
		EXECUTE DBA.NVL(fields.drop_old_field::text,'SELECT 1;'::text)::text;
		EXECUTE DBA.NVL(fields.create_new_field_type::text,'SELECT 1;'::text)::text;
		EXECUTE DBA.NVL(fields.swap_data_to_new_field::text,'SELECT 1;'::text)::text;
		EXECUTE DBA.NVL(fields.drop__temp_field::text,'SELECT 1;'::text)::text;
	END LOOP;
	RETURN 1;
END;
$$;

ALTER FUNCTION dba.script_diff_fields_types() OWNER TO postgres;

CREATE FUNCTION  dba.script_diff_tables() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    linha RECORD;
BEGIN
    FOR linha IN (
		SELECT 	('CREATE TABLE   '||dba.getctrl_parameters('oldSchema')||'.'||trim(lower(table_name)) ||'(
);') as diff_tables
		
 FROM 	dba.new_tables
		
 WHERE 	trim(lower(table_name)) NOT IN ( SELECT trim(lower(table_name)) 
 FROM dba.old_tables )
	)LOOP
        EXECUTE linha.diff_tables;
    END LOOP;
    RETURN 1;
END;
$$;

ALTER FUNCTION dba.script_diff_tables() OWNER TO postgres;

CREATE FUNCTION  dba.script_drop_old_contraints() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    linha  RECORD;
    in_catalog text;
    in_schema text;
BEGIN

	in_catalog := dba.getctrl_parameters('dataBase');
	in_schema  := dba.getctrl_parameters('oldSchema');
	FOR linha IN (	
		SELECT  (' ALTER TABLE ' ||table_schema||'.'||table_name ||' DROP CONSTRAINT '||constraint_name||' CASCADE;') as script
		FROM 	information_schema.table_constraints
		WHERE 	trim(constraint_catalog) = in_catalog 	
		AND	trim(constraint_schema)  = in_schema
		AND	trim(constraint_type)   in ('PRIMARY KEY','FOREIGN KEY')
		AND     trim(lower(table_name)) in ( SELECT trim(lower(table_name)) FROM dba.old_tables )
		ORDER BY constraint_type
		)LOOP
		EXECUTE linha.script;
	END LOOP;
	RETURN 1;
END;
$$;

ALTER FUNCTION dba.script_drop_old_contraints() OWNER TO postgres;

CREATE FUNCTION  dba.script_upgradedatabase() RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
   
BEGIN
	EXECUTE 'SELECT dba.script_drop_old_contraints();';
	EXECUTE 'SELECT dba.script_diff_tables();';
	EXECUTE 'SELECT dba.script_diff_fields();';
	EXECUTE 'SELECT dba.script_diff_fields_types();';
	EXECUTE 'SELECT dba.script_diff_fields_sizes();';
	EXECUTE 'SELECT dba.script_diff_views();';
	EXECUTE 'DROP TABLE '||dba.getctrl_parameters('oldSchema')||'.ad_elemento;   	CREATE TABLE '||dba.getctrl_parameters('oldSchema')||'.ad_elemento AS(SELECT * FROM '	||dba.getctrl_parameters('newSchema')||'.ad_elemento);';
	EXECUTE 'DROP TABLE '||dba.getctrl_parameters('oldSchema')||'.ad_fonte; 	CREATE TABLE '||dba.getctrl_parameters('oldSchema')||'.ad_fonte AS(SELECT * FROM ' 	||dba.getctrl_parameters('newSchema')||'.ad_fonte);';
	EXECUTE 'DROP TABLE '||dba.getctrl_parameters('oldSchema')||'.ad_tipoveiculo;	CREATE TABLE '||dba.getctrl_parameters('oldSchema')||'.ad_tipoveiculo AS(SELECT * FROM '||dba.getctrl_parameters('newSchema')||'.ad_tipoveiculo);';
	EXECUTE 'DROP TABLE '||dba.getctrl_parameters('oldSchema')||'.cm_banco;	  	CREATE TABLE '||dba.getctrl_parameters('oldSchema')||'.cm_banco AS(SELECT * FROM '	||dba.getctrl_parameters('newSchema')||'.cm_banco);';
	EXECUTE 'DROP TABLE '||dba.getctrl_parameters('oldSchema')||'.cm_estadocivil;	CREATE TABLE '||dba.getctrl_parameters('oldSchema')||'.cm_estadocivil AS(SELECT * FROM '||dba.getctrl_parameters('newSchema')||'.cm_estadocivil);';
	EXECUTE 'DROP TABLE '||dba.getctrl_parameters('oldSchema')||'.cm_pais;	  	CREATE TABLE '||dba.getctrl_parameters('oldSchema')||'.cm_pais AS(SELECT * FROM '	||dba.getctrl_parameters('newSchema')||'.cm_pais);';
	EXECUTE 'DROP TABLE '||dba.getctrl_parameters('oldSchema')||'.ad_subelemento;	CREATE TABLE '||dba.getctrl_parameters('oldSchema')||'.ad_subelemento AS(SELECT * FROM '||dba.getctrl_parameters('newSchema')||'.ad_subelemento);';
	EXECUTE 'DROP TABLE '||dba.getctrl_parameters('oldSchema')||'.cm_agencia;	CREATE TABLE '||dba.getctrl_parameters('oldSchema')||'.cm_agencia AS(SELECT * FROM '	||dba.getctrl_parameters('newSchema')||'.cm_agencia);';
	EXECUTE 'DROP TABLE '||dba.getctrl_parameters('oldSchema')||'.cm_municipio;  	CREATE TABLE '||dba.getctrl_parameters('oldSchema')||'.cm_municipio AS(SELECT * FROM '	||dba.getctrl_parameters('newSchema')||'.cm_municipio);';
	EXECUTE 'DROP TABLE '||dba.getctrl_parameters('oldSchema')||'.cm_uf;	  	CREATE TABLE '||dba.getctrl_parameters('oldSchema')||'.cm_uf AS(SELECT * FROM '	 	||dba.getctrl_parameters('newSchema')||'.cm_uf);';
	EXECUTE 'SELECT dba.script_create_new_contraints();';
	EXECUTE 'SELECT dba.script_diff_views();';
	RETURN 'O processo da atualização do banco de dados foi concluído!';
END;
$$;

ALTER FUNCTION dba.script_upgradedatabase() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

CREATE TABLE   dba.ctrl_log (
    idlog integer,
    datahora timestamp without time zone,
    descricao character varying(2000)

);

ALTER TABLE dba.ctrl_log OWNER TO postgres;

CREATE TABLE   dba.ctrl_parameters (
    identificador character varying(50),
    valor character varying(50),
    datatype character varying(30)

);

ALTER TABLE dba.ctrl_parameters OWNER TO postgres;

CREATE VIEW   dba.new_tables AS (
    	SELECT 	tables.table_schema, tables.table_name, new_pkfields((tables.table_name)::text) AS script_pk 
 	FROM 	information_schema.tables 
 	WHERE 	btrim(tables.table_type)::text  = 'BASE TABLE'::text
	AND 	tables.table_schema::text 	= dba.getctrl_parameters('newSchema')::text
	AND 	tables.table_catalog::text 	= 'dbsiga'::text
);

CREATE VIEW   dba.new_fields AS 
 SELECT create_fields.table_name, create_fields.column_name, create_fields.ordinal_position, create_fields.data_type, create_fields.character_maximum_length, create_fields.numeric_precision, create_fields.numeric_scale, create_fields.precisao, create_fields.is_nullable, replace((((((((('ALTER TABLE '||dba.getctrl_parameters('oldSchema')||'.'::text || (create_fields.table_name)::text) || ' ADD '::text) || (create_fields.column_name)::text) || ' '::text) || create_fields.data_type) || 
	CASE WHEN (btrim(create_fields.data_type) = ANY (ARRAY['date'::text, 'timestamp'::text, 'timestamptz'::text])) THEN ''::text ELSE (('('::text || create_fields.precisao) || ')'::text) END) || 
	CASE WHEN (btrim((create_fields.is_nullable)::text) = 'YES'::text) THEN ''::text ELSE 
	CASE 
		WHEN (btrim(create_fields.data_type) = 'date'::text) THEN ' NOT NULL'::text 
		WHEN (btrim(create_fields.data_type) = 'timestamp'::text) THEN ' NOT NULL'::text 
		WHEN (btrim(create_fields.data_type) = 'timestamptz'::text) THEN ' NOT NULL'::text 
		WHEN (btrim(create_fields.data_type) = 'bpchar'::text) THEN ' DEFAULT (0::TEXT)  NOT NULL'::text 
		WHEN (btrim(create_fields.data_type) = 'varchar'::text) THEN ' DEFAULT (0::TEXT)  NOT NULL'::text 
		WHEN (btrim(create_fields.data_type) = 'text'::text) THEN ' DEFAULT (0::TEXT)  NOT NULL'::text 
		WHEN (btrim(create_fields.data_type) = 'int4'::text) THEN ' DEFAULT 0  NOT NULL'::text 
		WHEN (btrim(create_fields.data_type) = 'oid'::text) THEN ' DEFAULT 0  NOT NULL'::text 
		WHEN (btrim(create_fields.data_type) = 'float8'::text) THEN ' DEFAULT 0  NOT NULL'::text 
		WHEN (btrim(create_fields.data_type) = 'numeric'::text) THEN ' DEFAULT 0  NOT NULL'::text ELSE NULL::text END END) || ';'::text), '()'::text, ''::text) AS script 
 FROM (SELECT columns.table_name, columns.column_name, columns.ordinal_position, 
	CASE 
		WHEN (btrim((columns.udt_name)::text) = 'date'::text) THEN 'date'::text 
		WHEN (btrim((columns.udt_name)::text) = 'timestamp'::text) THEN 'timestamp'::text 
		WHEN (btrim((columns.udt_name)::text) = 'timestamptz'::text) THEN 'timestamptz'::text 
		WHEN (btrim((columns.udt_name)::text) = 'bpchar'::text) THEN 'bpchar'::text 
		WHEN (btrim((columns.udt_name)::text) = 'varchar'::text) THEN 'varchar'::text 
		WHEN (btrim((columns.udt_name)::text) = 'text'::text) THEN 'text'::text 
		WHEN (btrim((columns.udt_name)::text) = 'int4'::text) THEN 'numeric'::text 
		WHEN (btrim((columns.udt_name)::text) = 'oid'::text) THEN 'oid'::text 
		WHEN (btrim((columns.udt_name)::text) = 'float8'::text) THEN 'numeric'::text 
		WHEN (btrim((columns.udt_name)::text) = 'numeric'::text) THEN 'numeric'::text ELSE NULL::text 
	END AS data_type, 
	columns.character_maximum_length, 
	columns.numeric_precision, 
	columns.numeric_scale, 
	columns.is_nullable, 
	columns.table_schema, 
	CASE WHEN (((columns.character_maximum_length IS NULL) AND (columns.numeric_precision IS NULL)) AND (columns.numeric_scale IS NULL)) THEN ''::text ELSE 
	CASE 
		WHEN (btrim((columns.udt_name)::text) = 'date'::text) THEN ''::text 
		WHEN (btrim((columns.udt_name)::text) = 'timestamp'::text) THEN ''::text 
 		WHEN (btrim((columns.udt_name)::text) = 'timestamptz'::text) THEN ''::text 
		WHEN (btrim((columns.udt_name)::text) = 'bpchar'::text) THEN (columns.character_maximum_length)::text 
		WHEN (btrim((columns.udt_name)::text) = 'varchar'::text) THEN (columns.character_maximum_length)::text 
		WHEN (btrim((columns.udt_name)::text) = 'text'::text) THEN (columns.character_maximum_length)::text 
		WHEN (btrim((columns.udt_name)::text) = 'int4'::text) THEN (columns.numeric_precision)::text 
		WHEN (btrim((columns.udt_name)::text) = 'oid'::text) THEN (columns.numeric_precision)::text 
		WHEN (btrim((columns.udt_name)::text) = 'float8'::text) THEN (((columns.numeric_precision)::text || ','::text) || nvl((columns.numeric_scale)::integer, 0)) 
		WHEN (btrim((columns.udt_name)::text) = 'numeric'::text) THEN (((columns.numeric_precision)::text || ','::text) || nvl((columns.numeric_scale)::integer, 0)) ELSE NULL::text END END AS precisao 
FROM 	information_schema.columns 
WHERE 	(columns.table_schema)::text = dba.getctrl_parameters('newSchema')::text
AND 	(columns.table_name)::text IN (SELECT new_tables.table_name FROM dba.new_tables)
ORDER BY columns.table_name, columns.column_name, columns.ordinal_position) create_fields;

CREATE VIEW   dba.new_fields_swap_type AS
    SELECT create_fields.table_name, create_fields.column_name, create_fields.data_type, (((((((('ALTER TABLE '::text || dba.getctrl_parameters('oldSchema')::text) || '.'::text) || (create_fields.table_name)::text) || ' ADD COLUMN temp_'::text) || (create_fields.column_name)::text) || ' '::text) || create_fields.data_type) || ';'::text) AS create_temp_field, (((((((((('UPDATE '::text || dba.getctrl_parameters('oldSchema')::text) || '.'::text) || (create_fields.table_name)::text) || ' SET temp_'::text) || (create_fields.column_name)::text) || ' = CAST (dba.nvl('::text) || (create_fields.column_name)::text) || ',0) AS '::text) || create_fields.data_type) || ');'::text) AS swap_data_to_temp_field, (((((('ALTER TABLE '::text || dba.getctrl_parameters('oldSchema')::text) || '.'::text) || (create_fields.table_name)::text) || ' DROP COLUMN '::text) || (create_fields.column_name)::text) || ' ;'::text) AS drop_old_field, (((((((('ALTER TABLE '::text || dba.getctrl_parameters('oldSchema')::text) || '.'::text) || (create_fields.table_name)::text) || ' ADD  COLUMN '::text) || (create_fields.column_name)::text) || ' '::text) || create_fields.data_type) || 
	CASE 
		WHEN (create_fields.data_type = 'date'::text) THEN ''::text 
		WHEN (create_fields.data_type = 'timestamp'::text) THEN ''::text 
		WHEN (create_fields.data_type = 'timestamptz'::text) THEN ''::text 
		WHEN (create_fields.data_type = 'bpchar'::text) THEN ((' DEFAULT CAST ( 0 AS '::text || create_fields.data_type) || ');'::text) 
	WHEN (create_fields.data_type = 'varchar'::text) THEN ((' DEFAULT CAST ( 0 AS '::text || create_fields.data_type) || ');'::text) 
	WHEN (create_fields.data_type = 'text'::text) THEN ((' DEFAULT CAST ( 0 AS '::text || create_fields.data_type) || ');'::text) 
	WHEN (create_fields.data_type = 'integer'::text) THEN ((' DEFAULT CAST ( 0 AS '::text || create_fields.data_type) || ');'::text) 
	WHEN (create_fields.data_type = 'oid'::text) THEN ((' DEFAULT CAST ( 0 AS '::text || create_fields.data_type) || ');'::text) 
	WHEN (create_fields.data_type = 'float8'::text) THEN ((' DEFAULT CAST ( 0 AS '::text || create_fields.data_type) || ');'::text) 
	WHEN (create_fields.data_type = 'numeric'::text) THEN ((' DEFAULT CAST ( 0 AS '::text || create_fields.data_type) || ');'::text) ELSE NULL::text END) AS create_new_field_type, (((((((('UPDATE '::text || dba.getctrl_parameters('oldSchema')::text) || '.'::text) || (create_fields.table_name)::text) || ' SET '::text) || (create_fields.column_name)::text) || ' = temp_'::text) || (create_fields.column_name)::text) || ';'::text) AS swap_data_to_new_field, ((((((('ALTER TABLE '::text || dba.getctrl_parameters('oldSchema')::text) || '.'::text) || (create_fields.table_name)::text) || ' DROP COLUMN '::text) || 'temp_'::text) || (create_fields.column_name)::text) || ';'::text) AS drop__temp_field 
 FROM (SELECT columns.table_name, columns.column_name, columns.ordinal_position, 
	CASE 
		WHEN (btrim((columns.udt_name)::text) = 'date'::text) THEN 'date'::text 
		WHEN (btrim((columns.udt_name)::text) = 'timestamp'::text) THEN 'timestamp'::text 
		WHEN (btrim((columns.udt_name)::text) = 'timestamptz'::text) THEN 'timestamptz'::text 
		WHEN (btrim((columns.udt_name)::text) = 'bpchar'::text) THEN 'bpchar'::text 
		WHEN (btrim((columns.udt_name)::text) = 'varchar'::text) THEN 'varchar'::text 
		WHEN (btrim((columns.udt_name)::text) = 'text'::text) THEN 'text'::text 
		WHEN (btrim((columns.udt_name)::text) = 'int4'::text) THEN 'integer'::text 
		WHEN (btrim((columns.udt_name)::text) = 'oid'::text) THEN 'oid'::text 
		WHEN (btrim((columns.udt_name)::text) = 'float8'::text) THEN 'numeric'::text 
		WHEN (btrim((columns.udt_name)::text) = 'numeric'::text) THEN 'numeric'::text ELSE NULL::text 
	END AS data_type, 
	columns.character_maximum_length, 
	columns.numeric_precision, 
	columns.numeric_scale, 
	columns.is_nullable, 
	columns.table_schema, 
	CASE 
 		WHEN (btrim((columns.udt_name)::text) = 'date'::text) THEN ''::text 
		WHEN (btrim((columns.udt_name)::text) = 'timestamp'::text) THEN ''::text 
		WHEN (btrim((columns.udt_name)::text) = 'timestamptz'::text) THEN ''::text 
		WHEN (btrim((columns.udt_name)::text) = 'bpchar'::text) THEN (columns.character_maximum_length)::text 
		WHEN (btrim((columns.udt_name)::text) = 'varchar'::text) THEN (columns.character_maximum_length)::text 
		WHEN (btrim((columns.udt_name)::text) = 'text'::text) THEN (columns.character_maximum_length)::text 
		WHEN (btrim((columns.udt_name)::text) = 'int4'::text) THEN (columns.numeric_precision)::text 
		WHEN (btrim((columns.udt_name)::text) = 'oid'::text) THEN (columns.numeric_precision)::text 
		WHEN (btrim((columns.udt_name)::text) = 'float8'::text) THEN (((columns.numeric_precision)::text || ','::text) || (columns.numeric_scale)::text) 
		WHEN (btrim((columns.udt_name)::text) = 'numeric'::text) THEN (((columns.numeric_precision)::text || ','::text) || (columns.numeric_scale)::text) ELSE NULL::text 
	END AS precisao 
FROM 	information_schema.columns 
WHERE 	columns.table_schema::text = dba.getctrl_parameters('newSchema')::text
AND 	columns.table_name::text IN (SELECT new_tables.table_name FROM dba.new_tables)
ORDER BY columns.table_name, columns.column_name, columns.ordinal_position) create_fields;

CREATE VIEW   dba.new_foreignkeys AS (
    	SELECT 	n.nspname AS esquema, cl.relname AS tabela, a.attname AS coluna, ct.conname AS chave, nf.nspname AS esquema_ref, clf.relname AS tabela_ref, af.attname AS coluna_ref, pg_get_constraintdef(ct.oid) AS criar_sql 
 	FROM 	pg_attribute a, pg_class cl, pg_namespace n, pg_constraint ct, pg_class clf, pg_namespace nf, pg_attribute af 
 	WHERE	a.attrelid = cl.oid
	AND 	cl.relkind = 'r'::"char"
	AND 	n.oid = cl.relnamespace 
	AND 	a.attrelid = ct.conrelid
	AND 	ct.confrelid <> (0)::oid
	AND 	ct.conkey[1] = a.attnum 
	AND 	ct.confrelid = clf.oid 
	AND 	clf.relkind = 'r'::"char"
	AND 	nf.oid = clf.relnamespace
	AND 	af.attrelid = ct.confrelid
	AND 	af.attnum = ct.confkey[1]
	AND 	n.nspname = dba.getctrl_parameters('newSchema')::name
);

CREATE VIEW   dba.new_functions AS (
	SELECT 	n.nspname, p.proname, p.prolang, p.prorettype, p.proargtypes 
	FROM 	pg_namespace n, pg_proc p 
	WHERE 	p.pronamespace 	= n.oid
	AND 	n.nspname 	= dba.getctrl_parameters('newSchema')::name
);

CREATE VIEW   dba.new_primarykey AS (
	SELECT 	pg_namespace.nspname AS esquema, pg_class.relname AS tabela, pg_attribute.attname AS coluna 
 	FROM 	pg_class, 
		pg_namespace, 
		pg_attribute, 
		pg_index 
 	WHERE 	pg_namespace.oid 	= pg_class.relnamespace
	AND 	pg_namespace.nspname 	!~~ 'pg_%'::text
	AND 	pg_index.indrelid 	= pg_class.oid
	AND 	pg_index.indisprimary 	= true
	AND 	pg_attribute.attrelid 	= pg_class.oid
	AND 	pg_attribute.attisdropped = false
	AND 	(	(pg_index.indkey[0] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[1] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[2] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[3] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[4] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[5] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[6] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[7] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[8] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[9] = pg_attribute.attnum)
		)
	AND 	pg_namespace.nspname 	= dba.getctrl_parameters('newSchema')::name
	ORDER BY pg_namespace.nspname, pg_class.relname, pg_attribute.attname
);

CREATE VIEW   dba.new_sequences AS
   SELECT temp.seqschema, temp.tabela, temp.seqname, temp.pk, dba.ifternario(temp.tabela IS NULL OR temp.pk IS NULL, 'MANUAL'::text, 'AUTOMATICA'::text) AS intervecao
   FROM ( 	SELECT n.nspname AS seqschema, 
                CASE                    
 			WHEN substr(c.relname::text, 1, 3) = 'seq'::text THEN substr(c.relname::text, 5, length(c.relname::text))    
			ELSE NULL::text
                END AS tabela, c.relname AS seqname, dba.new_pkfields(
                CASE				    
			WHEN substr(c.relname::text, 1, 3) = 'seq'::text THEN substr(c.relname::text, 5, length(c.relname::text))
			ELSE NULL::text
                END) AS pk
		FROM 	pg_class c, pg_namespace n
		WHERE 	c.relnamespace = n.oid 
		AND 	c.relkind = 'S'::"char" 
		AND 	n.nspname = dba.getctrl_parameters('newSchema')::name
		ORDER BY c.relname
  ) as temp
  ORDER BY 	temp.seqschema, 
		dba.ifternario(temp.tabela IS NULL OR temp.pk IS NULL, 'MANUAL'::text, 'AUTOMATICA'::text), 
		temp.tabela, 
		temp.seqname;

CREATE OR REPLACE VIEW dba.old_sequences AS 
 SELECT temp.seqschema, temp.tabela, temp.seqname, temp.pk, dba.ifternario(temp.tabela IS NULL OR temp.pk IS NULL, 'MANUAL'::text, 'AUTOMATICA'::text) AS intervecao
   FROM ( SELECT n.nspname AS seqschema, 
                CASE
                    WHEN substr(c.relname::text, 1, 3) = 'seq'::text THEN substr(c.relname::text, 5, length(c.relname::text))
                    ELSE NULL::text
                END AS tabela, c.relname AS seqname, dba.new_pkfields(
                CASE
                    WHEN substr(c.relname::text, 1, 3) = 'seq'::text THEN substr(c.relname::text, 5, length(c.relname::text))
                    ELSE NULL::text
                END) AS pk
           FROM pg_class c, pg_namespace n
          WHERE c.relnamespace = n.oid AND c.relkind = 'S'::"char" 
	  AND n.nspname = dba.getctrl_parameters('oldSchema'::text)::name
          ORDER BY c.relname) temp
  ORDER BY temp.seqschema, dba.ifternario(temp.tabela IS NULL OR temp.pk IS NULL, 'MANUAL'::text, 'AUTOMATICA'::text), temp.tabela, temp.seqname;

CREATE VIEW   dba.new_triggers AS (
	SELECT 	tables.table_schema, tables.table_name 
	FROM 	information_schema.tables 
	WHERE 	tables.table_schema::text 	= dba.getctrl_parameters('newSchema')::text
	AND 	tables.table_catalog::text 	= 'dbsiga'::text
);

CREATE VIEW   dba.new_view AS (
	SELECT 	pg_views.schemaname, pg_views.viewname, pg_views.definition 
	FROM 	pg_views 
	WHERE 	pg_views.schemaname = dba.getctrl_parameters('newSchema')::name
);

CREATE VIEW   dba.old_fields AS (
    	SELECT create_fields.table_name, create_fields.column_name, create_fields.ordinal_position, create_fields.data_type, create_fields.character_maximum_length, create_fields.numeric_precision, create_fields.numeric_scale, create_fields.precisao, create_fields.is_nullable, replace((((((((('ALTER TABLE '||dba.getctrl_parameters('oldSchema')||'.'::text || (create_fields.table_name)::text) || ' ADD '::text) || (create_fields.column_name)::text) || ' '::text) || create_fields.data_type) || 
		CASE WHEN (btrim(create_fields.data_type) = ANY (ARRAY['date'::text, 'timestamp'::text, 'timestamptz'::text])) THEN ''::text ELSE (('('::text || create_fields.precisao) || ')'::text) END) || 
		CASE WHEN (btrim((create_fields.is_nullable)::text) = 'YES'::text) THEN ''::text ELSE 
		CASE 
 			WHEN (btrim(create_fields.data_type) = 'date'::text) THEN ' NOT NULL'::text 
 			WHEN (btrim(create_fields.data_type) = 'timestamp'::text) THEN ' NOT NULL'::text 
 			WHEN (btrim(create_fields.data_type) = 'timestamptz'::text) THEN ' NOT NULL'::text 
 			WHEN (btrim(create_fields.data_type) = 'bpchar'::text) THEN ' DEFAULT (0::TEXT)  NOT NULL'::text 
 			WHEN (btrim(create_fields.data_type) = 'varchar'::text) THEN ' DEFAULT (0::TEXT)  NOT NULL'::text 
 			WHEN (btrim(create_fields.data_type) = 'text'::text) THEN ' DEFAULT (0::TEXT)  NOT NULL'::text 
 			WHEN (btrim(create_fields.data_type) = 'int4'::text) THEN ' DEFAULT 0  NOT NULL'::text 
 			WHEN (btrim(create_fields.data_type) = 'oid'::text) THEN ' DEFAULT 0  NOT NULL'::text 
 			WHEN (btrim(create_fields.data_type) = 'float8'::text) THEN ' DEFAULT 0  NOT NULL'::text 
 			WHEN (btrim(create_fields.data_type) = 'numeric'::text) THEN ' DEFAULT 0  NOT NULL'::text ELSE NULL::text 
		END 
	END) || ';'::text), '()'::text, ''::text) AS script 
 	FROM (
		SELECT columns.table_name, columns.column_name, columns.ordinal_position, 
			CASE 
				WHEN (btrim((columns.udt_name)::text) = 'date'::text) THEN 'date'::text 
				WHEN (btrim((columns.udt_name)::text) = 'timestamp'::text) THEN 'timestamp'::text 
 				WHEN (btrim((columns.udt_name)::text) = 'timestamptz'::text) THEN 'timestamptz'::text 
 				WHEN (btrim((columns.udt_name)::text) = 'bpchar'::text) THEN 'bpchar'::text 
 				WHEN (btrim((columns.udt_name)::text) = 'varchar'::text) THEN 'varchar'::text 
 				WHEN (btrim((columns.udt_name)::text) = 'text'::text) THEN 'text'::text 
				WHEN (btrim((columns.udt_name)::text) = 'int4'::text) THEN 'numeric'::text 
 				WHEN (btrim((columns.udt_name)::text) = 'oid'::text) THEN 'oid'::text 
 				WHEN (btrim((columns.udt_name)::text) = 'float8'::text) THEN 'numeric'::text 
 				WHEN (btrim((columns.udt_name)::text) = 'numeric'::text) THEN 'numeric'::text ELSE NULL::text 
			END AS data_type, 
				columns.character_maximum_length, 
				columns.numeric_precision, 
				columns.numeric_scale, 
				columns.is_nullable, 
				columns.table_schema, 		
			CASE WHEN (((columns.character_maximum_length IS NULL) AND (columns.numeric_precision IS NULL)) AND (columns.numeric_scale IS NULL)) THEN ''::text ELSE 
				CASE 
				WHEN (btrim((columns.udt_name)::text) = 'date'::text) 		THEN ''::text 
				WHEN (btrim((columns.udt_name)::text) = 'timestamp'::text) 	THEN ''::text 
 				WHEN (btrim((columns.udt_name)::text) = 'timestamptz'::text) 	THEN ''::text 
 				WHEN (btrim((columns.udt_name)::text) = 'bpchar'::text) 	THEN (columns.character_maximum_length)::text 
 				WHEN (btrim((columns.udt_name)::text) = 'varchar'::text) 	THEN (columns.character_maximum_length)::text 
 				WHEN (btrim((columns.udt_name)::text) = 'text'::text) 		THEN (columns.character_maximum_length)::text 
 				WHEN (btrim((columns.udt_name)::text) = 'int4'::text) 		THEN (columns.numeric_precision)::text 
 				WHEN (btrim((columns.udt_name)::text) = 'oid'::text) 		THEN (columns.numeric_precision)::text 
 				WHEN (btrim((columns.udt_name)::text) = 'float8'::text) 	THEN (((columns.numeric_precision)::text || ','::text) || nvl((columns.numeric_scale)::integer, 0)) 			
 				WHEN (btrim((columns.udt_name)::text) = 'numeric'::text) 	THEN (((columns.numeric_precision)::text || ','::text) || nvl((columns.numeric_scale)::integer, 0)) ELSE NULL::text 
				END 
			END AS precisao 
 		FROM 	information_schema.columns 
 		WHERE 	columns.table_schema::text = dba.getctrl_parameters('oldSchema')::text
		AND 	columns.table_name::text IN ( SELECT new_tables.table_name FROM dba.new_tables )
		ORDER BY columns.table_name, columns.column_name, columns.ordinal_position
		) as create_fields
);

CREATE VIEW   dba.old_foreignkeys AS (
	SELECT 	n.nspname 	AS esquema, 
		cl.relname 	AS tabela, 
		a.attname 	AS coluna, 
		ct.conname 	AS chave, 
		nf.nspname 	AS esquema_ref, 
		clf.relname 	AS tabela_ref, 
		af.attname 	AS coluna_ref, 
		pg_get_constraintdef(ct.oid) AS criar_sql 
	FROM 	pg_attribute a, 
		pg_class cl, 
		pg_namespace n, 
		pg_constraint ct, 
		pg_class clf, 
		pg_namespace nf, 
		pg_attribute af 
	WHERE 	a.attrelid = cl.oid
	AND 	cl.relkind = 'r'::"char"
	AND 	n.oid = cl.relnamespace
	AND 	a.attrelid = ct.conrelid
	AND 	ct.confrelid <> (0)::oid
	AND 	ct.conkey[1] = a.attnum
	AND 	ct.confrelid = clf.oid
	AND 	clf.relkind = 'r'::"char"
	AND 	nf.oid = clf.relnamespace
	AND 	af.attrelid = ct.confrelid
	AND 	af.attnum = ct.confkey[1]
	AND 	n.nspname = dba.getctrl_parameters('oldSchema')::name
);

ALTER TABLE dba.old_foreignkeys OWNER TO postgres;

CREATE VIEW   dba.old_functions AS (
	SELECT 	n.nspname, p.proname, p.prolang, p.prorettype, p.proargtypes 
	FROM 	pg_namespace n, pg_proc p 
	WHERE	p.pronamespace 	= n.oid
	AND	n.nspname 	= dba.getctrl_parameters('oldSchema')::name
);

CREATE VIEW   dba.old_primarykey AS (
	SELECT 	pg_namespace.nspname AS esquema, pg_class.relname AS tabela, pg_attribute.attname AS coluna 
	FROM 	pg_class, 
		pg_namespace, 
		pg_attribute, pg_index 
	WHERE 	pg_namespace.oid = pg_class.relnamespace
	AND 	pg_namespace.nspname !~~ 'pg_%'::text
	AND 	pg_index.indrelid = pg_class.oid
	AND	pg_index.indisprimary = true
	AND	pg_attribute.attrelid = pg_class.oid
	AND	pg_attribute.attisdropped = false
	AND 	(	(pg_index.indkey[0] = pg_attribute.attnum)
		OR 	(pg_index.indkey[1] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[2] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[3] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[4] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[5] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[6] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[7] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[8] = pg_attribute.attnum) 
		OR 	(pg_index.indkey[9] = pg_attribute.attnum)
		)
	AND 	pg_namespace.nspname = dba.getctrl_parameters('oldSchema')::name
	ORDER BY pg_namespace.nspname, pg_class.relname, pg_attribute.attname
);

CREATE VIEW   dba.old_tables AS (
    	SELECT 	tables.table_schema, tables.table_name, old_pkfields((tables.table_name)::text) AS script_pk 
	FROM 	information_schema.tables 
	WHERE 	tables.table_schema::text 	= dba.getctrl_parameters('oldSchema')::text
	AND 	tables.table_catalog::text 	= 'dbsiga'::text
);

CREATE VIEW   dba.old_triggers AS (
	SELECT 	tables.table_schema, tables.table_name 
	FROM 	information_schema.tables 
	WHERE 	tables.table_schema::text 	= dba.getctrl_parameters('oldSchema')::text
	AND 	tables.table_catalog::text 	= dba.getctrl_parameters('dataBase')::text
);

CREATE VIEW   dba.old_view AS (
	SELECT 	pg_views.schemaname, pg_views.viewname, pg_views.definition 
	FROM 	pg_views 
	WHERE 	pg_views.schemaname = dba.getctrl_parameters('oldSchema')::name
);



CREATE OR REPLACE FUNCTION dba.script_diff_views()
  RETURNS integer AS
$BODY$
DECLARE
    lines  RECORD;
BEGIN

FOR lines IN (	SELECT 	(  'DROP VIEW '||viewname||'; '||' CREATE OR REPLACE VIEW '||viewname||' AS '|| definition ) as script
		FROM 	dba.new_view 
		WHERE   schemaname = dba.getctrl_parameters('newSchema')::text
	)LOOP
		EXECUTE lines.script; 
	END LOOP;
	RETURN 1;
END;
$BODY$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION dba.script_diff_sequences()
  RETURNS integer AS
$BODY$
DECLARE
    lines  RECORD;
BEGIN

FOR lines IN (	SELECT ('CREATE SEQUENCE '||dba.getctrl_parameters('oldSchema')||'.'|| seqname ||' INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 1 CACHE 1;') as script
		FROM	dba.new_sequences
		WHERE   seqname NOT IN( SELECT o.seqname FROM dba.old_sequences o)
	)LOOP
		EXECUTE lines.script; 
	END LOOP;

lines := null;
FOR lines IN (	SELECT 'SELECT setval('|| (dba.getctrl_parameters('oldSchema')||'.'||seqname) || ', '|| script ||' , true);' as script 
		FROM	(
			SELECT 	seqschema, tabela, seqname, pk, intervecao , ('SELECT MAX('|| pk ||')+1 FROM '||dba.getctrl_parameters('oldSchema')||'.'||tabela ) as script
			FROM	dba.new_sequences ns
			WHERE   seqname NOT IN( SELECT o.seqname FROM dba.old_sequences o)
			AND TRIM(intervecao) = 'AUTOMATICA'
			) as ns
	)LOOP
		EXECUTE lines.script; 
	END LOOP;

	RETURN 1;
END;
$BODY$ LANGUAGE plpgsql;



