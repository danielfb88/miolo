

CREATE FUNCTION fn_ad_fornecedor_ins() RETURNS trigger   LANGUAGE plpgsql  AS '
BEGIN
	NEW.idagenc  = trim(NEW.idagenc);
	RETURN NEW;
END;';

CREATE FUNCTION fn_cm_agencia_ins() RETURNS trigger   LANGUAGE plpgsql  AS '
BEGIN
	NEW.idagenc  = trim(NEW.idagenc);
	RETURN NEW;
END;';

CREATE FUNCTION fn_cm_instituicao_ins() RETURNS trigger   LANGUAGE plpgsql  AS '
BEGIN
	NEW.sigla  = trim(NEW.sigla);
	NEW.uasg  = trim(NEW.uasg);
	NEW.ug  = trim(NEW.ug);
	RETURN NEW;
END;';

CREATE FUNCTION fn_cm_uf_ins() RETURNS trigger   LANGUAGE plpgsql  AS '
BEGIN
	NEW.iduf  = trim(NEW.iduf);
	NEW.uf  = trim(NEW.uf);
	RETURN NEW;
END;';

CREATE FUNCTION nvl(bigint, bigint) RETURNS bigint
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(bit, bit) RETURNS bit
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(bit varying, bit varying) RETURNS bit varying
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(boolean, boolean) RETURNS boolean
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(box, box) RETURNS box
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(bytea, bytea) RETURNS bytea
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(character varying, character varying) RETURNS character varying
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(character, character) RETURNS character
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(cidr, cidr) RETURNS cidr
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(circle, circle) RETURNS circle
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(date, date) RETURNS date
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(double precision, double precision) RETURNS double precision
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(inet, inet) RETURNS inet
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(integer, integer) RETURNS integer
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(interval, interval) RETURNS interval
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(line, line) RETURNS line
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(lseg, lseg) RETURNS lseg
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(macaddr, macaddr) RETURNS macaddr
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(money, money) RETURNS money
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(numeric, numeric) RETURNS numeric
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(path, path) RETURNS path
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(point, point) RETURNS point
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(polygon, polygon) RETURNS polygon
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(real, real) RETURNS real
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(smallint, smallint) RETURNS smallint
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(text, text) RETURNS text
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(time without time zone, time without time zone) RETURNS time without time zone
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE FUNCTION nvl(timestamp without time zone, timestamp without time zone) RETURNS timestamp without time zone
    LANGUAGE plpgsql  AS 'DECLARE 
		ENTRADA ALIAS FOR $1;
		ALTERNATIVA ALIAS FOR $2; 
	BEGIN 
		if (ENTRADA isnull) then return ALTERNATIVA;  
		else return ENTRADA; 
	end if; 
END';

CREATE TRIGGER tg_trim_ad_fornecedor
    BEFORE INSERT ON ad_fornecedor
    FOR EACH ROW
    EXECUTE PROCEDURE fn_ad_fornecedor_ins();

CREATE TRIGGER tg_trim_cm_agencia
    BEFORE INSERT ON cm_agencia
    FOR EACH ROW
    EXECUTE PROCEDURE fn_cm_agencia_ins();

CREATE TRIGGER tg_trim_cm_instituicao
    BEFORE INSERT ON cm_instituicao
    FOR EACH ROW
    EXECUTE PROCEDURE fn_cm_instituicao_ins();

CREATE TRIGGER tg_trim_cm_uf
    BEFORE INSERT ON cm_uf
    FOR EACH ROW
    EXECUTE PROCEDURE fn_cm_uf_ins();


CREATE OR REPLACE FUNCTION gatilho_cm_pessoa() RETURNS trigger AS $BODY$
BEGIN	
	IF NEW.datacartest  = '0001-01-01 BC' THEN
		NEW.datacartest := null;
        END IF;
	IF NEW.datanasc  = '0001-01-01 BC' THEN
		NEW.datanasc := null;
        END IF;
	IF NEW.datapispasep = '0001-01-01 BC' THEN
		NEW.datapispasep := null;
        END IF;
	IF NEW.datarg = '0001-01-01 BC' THEN
		NEW.datarg := null;
        END IF;
	IF NEW.dataultalt = '0001-01-01 BC' THEN
		NEW.dataultalt := null;
        END IF;  
      	RETURN NEW;
END;
$BODY$ LANGUAGE plpgsql VOLATILE COST 100;

CREATE OR REPLACE FUNCTION gatilho_rh_funcionario() RETURNS trigger AS $BODY$
BEGIN	
	IF NEW.dataprimeiroemprego  = '0001-01-01 BC' THEN
		NEW.dataprimeiroemprego := null;
        END IF;
      	RETURN NEW;
END;
$BODY$ LANGUAGE plpgsql VOLATILE COST 100;

CREATE OR REPLACE FUNCTION gatilho_rh_vinculo() RETURNS trigger AS $BODY$
BEGIN
	IF NEW.dataposse  = '0001-01-01 BC' THEN
		NEW.dataposse := null;
        END IF;
	IF NEW.dataexercicio  = '0001-01-01 BC' THEN
		NEW.dataposse := null;
        END IF;
	IF NEW.dataconcurso = '0001-01-01 BC' THEN
		NEW.dataconcurso := null;
        END IF;
	IF NEW.datafimcontrato = '0001-01-01 BC' THEN
		NEW.datafimcontrato := null;
        END IF;
	IF NEW.datavacancia = '0001-01-01 BC' THEN
		NEW.datavacancia := null;
        END IF;      
      	RETURN NEW;
END;
$BODY$ LANGUAGE plpgsql VOLATILE COST 100;

CREATE OR REPLACE FUNCTION gatilho_rh_provimento() RETURNS trigger AS $BODY$
BEGIN
	IF NEW.datainicio  = '0001-01-01 BC' THEN
		NEW.datainicio := null;
        END IF;
	IF NEW.datafim  = '0001-01-01 BC' THEN
		NEW.datafim := null;
        END IF;
      	RETURN NEW;
END;
$BODY$ LANGUAGE plpgsql VOLATILE COST 100;

CREATE OR REPLACE FUNCTION gatilho_rh_vaga() RETURNS trigger AS $BODY$
BEGIN
	IF NEW.datainicio  = '0001-01-01 BC' THEN
		NEW.datainicio := null;
        END IF;
	IF NEW.datafim  = '0001-01-01 BC' THEN
		NEW.datafim := null;
        END IF;
      	RETURN NEW;
END;
$BODY$ LANGUAGE plpgsql VOLATILE COST 100;

CREATE TRIGGER trigger_cm_pessoa
  BEFORE INSERT OR UPDATE
  ON cm_pessoa
  FOR EACH ROW
  EXECUTE PROCEDURE gatilho_cm_pessoa();

CREATE TRIGGER trigger_rh_funcionario
  BEFORE INSERT OR UPDATE
  ON rh_funcionario
  FOR EACH ROW
  EXECUTE PROCEDURE gatilho_rh_funcionario();

CREATE TRIGGER trigger_rh_vinculo
  BEFORE INSERT OR UPDATE
  ON rh_vinculo
  FOR EACH ROW
  EXECUTE PROCEDURE gatilho_rh_vinculo();

CREATE TRIGGER trigger_rh_provimento
  BEFORE INSERT OR UPDATE
  ON rh_provimento
  FOR EACH ROW
  EXECUTE PROCEDURE gatilho_rh_provimento();

CREATE TRIGGER trigger_rh_vaga
  BEFORE INSERT OR UPDATE
  ON rh_vaga
  FOR EACH ROW
  EXECUTE PROCEDURE gatilho_rh_vaga();
